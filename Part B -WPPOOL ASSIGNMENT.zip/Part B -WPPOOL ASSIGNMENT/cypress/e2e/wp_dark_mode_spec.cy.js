describe('WordPress Automation Tests for WP Dark Mode Plugin', () => {

  // 1. Log in to your WordPress site
  it('Logs into the WordPress Dashboard', () => {
      cy.visit('http://localhost/wordpress/wp-login.php');
      cy.get('#user_login').type('');
      cy.get('#user_pass').type('');
      cy.get('#wp-submit').click();
      
      // Verify successful login by checking for the admin bar
      cy.get('#wpadminbar', { timeout: 10000 }).should('be.visible');
  });

  // 2. Check whether the "WP Dark Mode" Plugin is Active or not
  it('Checks if WP Dark Mode plugin is active, if not installs it', () => {
      cy.visit('http://localhost/wordpress/wp-login.php');
      cy.get('#user_login').type('');
      cy.get('#user_pass').type('');
      cy.get('#wp-submit').click();
      cy.get('#wpadminbar', { timeout: 10000 }).should('be.visible');
      cy.get('#menu-plugins > .wp-has-submenu > .wp-menu-name').click();

      // Search for WP Dark Mode plugin
      cy.get('#plugin-search-input').type('WP Dark Mode');
      cy.get('#the-list').then(($pluginList) => {
          if ($pluginList.text().includes('WP Dark Mode')) {
              // Plugin is already installed
              cy.log('WP Dark Mode plugin is already installed');
              cy.screenshot('plugin-installed');
          } else {
              // Install the WP Dark Mode plugin
              cy.get('#menu-plugins > .wp-submenu > :nth-child(3) > a').click();
              cy.get('#search-plugins').type('WP Dark Mode');
              cy.wait(5000);
              cy.get('.plugin-card-wp-dark-mode > .plugin-card-top > .action-links > .plugin-action-buttons > :nth-child(1) > .install-now').click();
              cy.wait(5000);
              // Activate the plugin
              cy.get('.activate-now').should('be.visible').click();
              cy.contains('Plugin activated').should('exist');
              cy.screenshot('plugin-activated');
          }
      });
  });

  // 3. Enable Admin Dashboard Dark Mode
  it('Enables Admin Dashboard Dark Mode', () => {
      // Navigate to WP Dark Mode
      cy.visit('http://localhost/wordpress/wp-login.php');
      cy.get('#user_login').type('');
      cy.get('#user_pass').type('');
      cy.get('#wp-submit').click();
      cy.get('#wpadminbar', { timeout: 10000 }).should('be.visible');
      cy.get('#menu-plugins > .wp-has-submenu > .wp-menu-name').click();
      cy.get('#toplevel_page_wp-dark-mode > .wp-menu-name').click();

      // Enable Admin Dashboard Dark Mode
      cy.get('a[href="#tab-controls"]').click();
      cy.get('#wp-dark-mode-switch-admin').check({ force: true });
      cy.get('#wp-dark-mode-save-settings').click();

      // Validate dark mode is working on the dashboard
      cy.get('body').should('have.class', 'wp-dark-mode-active');
      cy.screenshot('admin-dark-mode-enabled');
  });

  it('Changes the Floating Switch Style', () => {
    cy.visit('http://localhost/wordpress/wp-login.php');
    cy.wait(1000);
    cy.get('#user_login').type('');
    cy.get('#user_pass').type('');
    cy.get('#wp-submit').click();

    cy.get('#toplevel_page_wp-dark-mode > .wp-has-submenu > .wp-menu-name').click();
    cy.wait(3000); // Increase the wait time

    cy.get('#toplevel_page_wp-dark-mode > .wp-submenu > li.wp-first-item > .wp-first-item').click(); // Change to another style
});


  // 5. Customize Switch Size and Position
  it('Changes the Switch Customization size and position', () => {
    // Customization - Change size and scale
    cy.visit('http://localhost/wordpress/wp-admin/admin.php?page=wp-dark-mode');
    cy.get('a[href="#tab-customization"]').click();
    cy.get('#floating_switch_scale').invoke('val', 220).trigger('change'); // Scale to 220
    cy.get('#floating_switch_position').select('Left'); // Change position to Left
    cy.get('#wp-dark-mode-save-settings').click();
    cy.screenshot('switch-size-and-position-changed');
});

// 6. Disable Keyboard Shortcut in Accessibility
it('Disables the Keyboard Shortcut from Accessibility Settings', () => {
    cy.visit('http://localhost/wordpress/wp-admin/admin.php?page=wp-dark-mode');
    cy.get('a[href="#tab-accessibility"]').click();
    cy.get('#disable_keyboard_shortcut').check({ force: true });
    cy.get('#wp-dark-mode-save-settings').click();
    cy.screenshot('keyboard-shortcut-disabled');
});
// 4. Change "Floating Switch Style"
it('Changes the Floating Switch Style', () => {
  cy.visit('http://localhost/wordpress/wp-login.php');
  cy.wait(1000)
  cy.get('#user_login').type('');
  cy.get('#user_pass').type('');
  cy.get('#wp-submit').click();
  cy.get('#toplevel_page_wp-dark-mode > .wp-has-submenu > .wp-menu-name').click();
  cy.get('#toplevel_page_wp-dark-mode > .wp-submenu > li.wp-first-item > .wp-first-item').click(); // Change to another style
 
});
// 7. Enable Page Transition Animation
it('Enables Page-Transition Animation', () => {
  cy.visit('http://localhost/wordpress/wp-login.php');
  cy.wait(1000)
  cy.get('#user_login').type('');
  cy.get('#user_pass').type('');
  cy.get('#wp-submit').click();
    cy.get('a[href="#tab-site-animation"]').click();
    cy.get('#enable_page_transition_animation').check({ force: true });
    cy.get('#page_transition_animation_effect').select('Slide');
    cy.get('#wp-dark-mode-save-settings').click();
    cy.screenshot('page-transition-animation-enabled');
});

// 8. Validate dark mode is working from the frontend
it('Validates dark mode is working on the frontend', () => {
  cy.visit('http://localhost/wordpress/wp-login.php');
  cy.wait(1000)
  cy.get('#user_login').type('');
  cy.get('#user_pass').type('');
  cy.get('#wp-submit').click();
    cy.get('body').should('have.class', 'wp-dark-mode-active');
    cy.screenshot('dark-mode-frontend');
});

});